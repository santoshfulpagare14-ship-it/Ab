# VoiceFloat - Floating Voice Dictation for Any App

Tap any text field in any app -> keyboard opens -> floating mic button appears instantly.
Tap mic to speak (Hindi / English / Hinglish) -> tap again to stop -> text is transcribed with Gemini and copied to clipboard. Paste anywhere.

Built for **Android 13 (API 33) / realme UI 4.0 / realme 9i**. Works on any Android 8+ phone.

## Why it is fast (<1 second, typically 50-150ms)

Android has **no direct API** to know when the keyboard opens in another app.
VoiceFloat uses the only reliable fast signal:

**`AccessibilityService` watching `TYPE_INPUT_METHOD` windows.**

| Trick | Why it matters |
|---|---|
| `notificationTimeout = 0` in `accessibility_service_config.xml` | System delivers events immediately, no batching delay |
| Overlay view **pre-inflated once** in `onServiceConnected()` | Showing = just `WindowManager.addView()`. No inflate / disk / network in detection path |
| `onAccessibilityEvent` only posts a **30ms coalescing runnable** | Bursts of window events collapse to one `getWindows()` check |
| Check is just: `window.type == TYPE_INPUT_METHOD && window.isVisible` | No polling, no UsageStats, no loops |
| No heavy work in detection path | Transcription / network happens only in `VoiceDictationService` after you tap Stop |

Fallback for realme: on some realme builds `getWindows()` can be empty for one frame. If a focused node was editable in the last 800ms, we treat that as keyboard-about-to-open and show the button. We **never read the node's text**.

**Privacy:** Accessibility is used ONLY to detect keyboard visibility. It does NOT read screen text, passwords, or keystrokes.

## Features

- Floating button appears when keyboard opens in **any app** (WhatsApp, Notes, Chrome, Gmail...)
- Tap to start, tap again to stop + transcribe + copy to clipboard
- Hindi, English, mixed Hinglish - preserves code-mix, adds punctuation + symbols (%, Rs., numbers)
- Pause / Resume while recording (optional, in overlay controls)
- Delete last recording: discards current recording OR deletes last transcription + clears clipboard if it still holds that text
- Drag floating button to move it
- Recording runs in a **foreground service** (`microphone` type) + partial wake lock, so it keeps working when screen is off
- Gemini API key stored with **EncryptedSharedPreferences (AES256-GCM)**
- Result card shows transcription with Copy again / Delete

## Get the APK (easiest - no computer needed for install)

### Option A: GitHub Actions (recommended)

1. Push this project to a GitHub repo, branch `main`.
2. Go to repo > **Actions** > **Build APK** > wait for green tick (~2-4 min).
3. Go to **Actions** > latest run > **Artifacts** > download `VoiceFloat-debug-apk`.
4. Unzip on your phone - you get `app-debug.apk`.

### Option B: Build locally

```bash
# Android Studio: Open project > Build > Build APK(s) > Build APK(s)
# OR command line:
./gradlew assembleDebug
# APK at: app/build/outputs/apk/debug/app-debug.apk
```

> Debug APK is directly installable for sideloading. Release APK in the workflow is unsigned - for Play Store you need signing.

## Setup: API Key

1. Go to **Google AI Studio**: https://aistudio.google.com/apikey
2. Sign in with Google, click **Create API key** > copy it (starts with `AIza...`).
3. Open VoiceFloat > paste key > **Save Key** > **Test Key** (should say Key works).
4. **A Gemini app subscription does NOT provide API access by itself.** You need the API key above. Free tier is enough for personal dictation.

## Setup: Permissions (in VoiceFloat app, in order)

| Permission | Why | How to grant |
|---|---|---|
| **Display over other apps** | Show mic button over keyboard in any app | VoiceFloat > Allow Display Over Other Apps > find VoiceFloat > Allow |
| **Microphone** | Record voice | VoiceFloat > Allow Microphone > Allow |
| **Accessibility - Keyboard Detector** | Detect when keyboard opens | VoiceFloat > Enable Keyboard Detection > find VoiceFloat Keyboard Detector > ON. It only detects keyboard, does not read content. |
| **Notifications** | Show recording indicator | VoiceFloat > Allow Notifications |
| **Battery optimisation exemption** | Prevent realme killing recording when screen off | VoiceFloat > Disable Battery Optimisation > Allow |

After all 4, open WhatsApp / Notes, tap a text field - mic button should appear at bottom-right above keyboard in <1s.

## Step-by-step Install - realme 9i (Android 13 / realme UI 4.0)

This is the exact flow that works on realme UI 4.0 - realme is aggressive about killing background apps, so do **all** steps:

### 1. Install APK

1. Download `app-debug.apk` from GitHub Actions (above) to your realme 9i.
2. Tap the APK file > **Install** (if asked, allow **Install unknown apps** for Chrome / Files > toggle ON > go back > Install).
3. If Play Protect warns: tap **More details** > **Install anyway** (this is your own debug build, not from Play Store).
4. Open **VoiceFloat** once.

### 2. Grant permissions inside VoiceFloat

Follow the Setup table above in order. Do not skip Accessibility - without it the button cannot know keyboard opened.

### 3. realme-specific: keep it alive (CRITICAL)

1. **Settings > App management > VoiceFloat > Auto-start** > ON
2. **Settings > Battery > VoiceFloat** > Allow background running / Don't optimise (wording varies: choose **Don't optimise** / **Allow**)
3. **Settings > App management > VoiceFloat > Battery usage** > Allow background activity
4. **Settings > App management > VoiceFloat > Floating window / Display over other apps** > Allow (same as step 2, double-check)
5. **Recent apps**: Open VoiceFloat, go to Recents, tap 3-dot / lock icon on VoiceFloat card > **Lock** (so swiping away Recents does not kill it). Keep this locked.
6. **Settings > Battery > Battery optimisation > VoiceFloat** > Don't optimise

### 4. Test

1. Open **WhatsApp** > any chat > tap message box.
2. Keyboard opens -> **pink mic button** appears bottom-right above keyboard in <1s.
3. Tap mic -> speak: `Kal meeting 3 baje hai, please notes bhej dena.` -> tap mic again.
4. Wait 2-5s for Gemini -> Toast **Copied to clipboard** -> long-press message box > **Paste**.
5. If button does not appear: re-check Accessibility ON + Overlay ON + Auto-start ON + restart phone once.

## How to use

- **Start:** Tap floating mic (vibrates, shows Recording...)
- **Pause / Resume:** Tap pause icon in overlay controls (|| / ▶)
- **Stop:** Tap mic again (or stop icon) -> transcribes -> copies
- **Delete current:** Tap trash icon while recording -> discards, tap mic to restart
- **Delete last:** In result card tap Delete, or in VoiceFloat tap Delete Last Recording
- **Move button:** Drag mic button

## Troubleshooting

| Problem | Fix |
|---|---|
| Button never appears | Accessibility OFF? Overlay OFF? Test in WhatsApp, not in VoiceFloat settings (button hides in own app to avoid covering API key field). Restart phone after enabling Accessibility. |
| Button appears late / disappears | realme killed service. Do all realme steps above + Lock in Recents + Don't optimise. |
| Mic fails / other app using mic | Close voice recorder / Google Assistant, retry. |
| Gemini error 400 / API key invalid | Key copied wrong? Get new key at AI Studio, Save + Test again. Check internet. |
| Transcription empty / [inaudible] | Speak closer, louder, check mic not covered. Try English first to confirm pipeline. |
| Recording stops when screen off | Battery optimisation still ON. Set Don't optimise + Auto-start + Lock in Recents. Foreground notification must stay visible. |
| Paste shows old text | Wait for Copied toast before pasting. If Delete Last cleared clipboard, re-dictate. |

## Project structure

```
app/src/main/java/com/voicefloat/app/
  MainActivity.kt                  - Setup UI, permissions explainer, API key
  KeyboardAccessibilityService.kt  - FAST keyboard detection + overlay button
  VoiceDictationService.kt         - Foreground recording, pause/resume, clipboard
  GeminiTranscriber.kt            - Gemini 2.5 Flash audio -> text
  SecureKeyStore.kt               - EncryptedSharedPreferences for API key
app/src/main/res/layout/
  activity_main.xml                - Setup screen
  overlay_floating.xml            - Floating mic + controls + result card
app/src/main/res/xml/accessibility_service_config.xml - notificationTimeout=0
.github/workflows/build-apk.yml   - Builds APK on push to main, uploads artifact
```

## Build / Release

- Workflow: `.github/workflows/build-apk.yml` - runs on push to `main`, builds Debug + Release (unsigned), uploads both as artifacts.
- Local: `./gradlew assembleDebug`
- Target: `targetSdk 33`, `minSdk 26`, `compileSdk 34`, JDK 17.

## Cost / Limits

Gemini API free tier is enough for personal dictation (short clips). Long recordings (>2 min) use more quota and take longer to transcribe. Keep dictations under ~60s for best speed/accuracy.

## License

Personal use. No data leaves phone except audio sent to Gemini for transcription (with your own key).
