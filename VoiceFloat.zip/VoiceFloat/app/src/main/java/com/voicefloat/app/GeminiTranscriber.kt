package com.voicefloat.app

import android.util.Base64
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

/**
 * Gemini speech-to-text.
 * Sends recorded audio (m4a) to Gemini 2.5 Flash with a transcription prompt.
 * Hindi / English / Hinglish aware: prompt forces code-mix preservation,
 * proper punctuation and symbols, and return-only-transcription.
 *
 * NOTE: A Gemini app subscription does NOT give API access.
 * The user needs a key from Google AI Studio: https://aistudio.google.com/apikey
 */
object GeminiTranscriber {

    private const val MODEL = "gemini-2.5-flash"
    private const val ENDPOINT =
        "https://generativelanguage.googleapis.com/v1beta/models/%s:generateContent"

    private const val SYSTEM_PROMPT = """
You are a precise speech transcription engine for India.
Transcribe the audio exactly as spoken.
Languages: Hindi (Devanagari or Roman as spoken), English, and mixed Hinglish.
Rules:
- Preserve code-mixing exactly. If user says Hinglish in Roman, keep Roman. If user says Hindi in Devanagari, keep Devanagari. Do not translate.
- Add proper punctuation: commas, full stops, question marks, exclamation, quotes.
- Add symbols where spoken: %, Rs., $, numbers as digits, email / phone as spoken.
- Keep filler words out unless they change meaning. Remove long pauses.
- Do not add explanations, headers, or markdown. Return ONLY the transcription text.
- If audio is silent or unintelligible, return exactly: [inaudible]
"""

    suspend fun transcribe(apiKey: String, audioFile: File): Result<String> =
        withContext(Dispatchers.IO) {
            try {
                if (!audioFile.exists() || audioFile.length() == 0L) {
                    return@withContext Result.failure(Exception("Recording is empty. Try again, speak closer to mic."))
                }
                val bytes = audioFile.readBytes()
                val b64 = Base64.encodeToString(bytes, Base64.NO_WRAP)

                val partAudio = JSONObject().apply {
                    put("inline_data", JSONObject().apply {
                        put("mime_type", "audio/mp4")
                        put("data", b64)
                    })
                }
                val partText = JSONObject().apply { put("text", SYSTEM_PROMPT) }
                val content = JSONObject().apply {
                    put("parts", JSONArray().apply {
                        put(partText)
                        put(partAudio)
                    })
                }
                val body = JSONObject().apply {
                    put("contents", JSONArray().apply { put(content) })
                    put("generationConfig", JSONObject().apply {
                        put("temperature", 0.0)
                        put("maxOutputTokens", 4096)
                    })
                }

                val url = URL(String.format(ENDPOINT, MODEL) + "?key=" + apiKey)
                val conn = (url.openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"
                    setRequestProperty("Content-Type", "application/json")
                    connectTimeout = 30_000
                    readTimeout = 60_000
                    doOutput = true
                }
                conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }

                val code = conn.responseCode
                val raw = if (code in 200..299) {
                    conn.inputStream.bufferedReader().readText()
                } else {
                    val err = try { conn.errorStream?.bufferedReader()?.readText() } catch (e: Exception) { "" }
                    return@withContext Result.failure(Exception("Gemini error $code: ${parseError(err)}"))
                }
                val text = parseText(raw)
                if (text.isBlank()) {
                    Result.failure(Exception("Gemini returned empty transcription. Try again."))
                } else {
                    Result.success(text.trim())
                }
            } catch (e: Exception) {
                Result.failure(e)
            }
        }

    suspend fun testKey(apiKey: String): Result<Boolean> = withContext(Dispatchers.IO) {
        try {
            val body = JSONObject().apply {
                put("contents", JSONArray().apply {
                    put(JSONObject().apply {
                        put("parts", JSONArray().apply {
                            put(JSONObject().apply { put("text", "Reply with exactly: OK") })
                        })
                    })
                })
            }
            val url = URL(String.format(ENDPOINT, MODEL) + "?key=" + apiKey)
            val conn = (url.openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                setRequestProperty("Content-Type", "application/json")
                connectTimeout = 15_000
                readTimeout = 15_000
                doOutput = true
            }
            conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
            if (conn.responseCode in 200..299) Result.success(true)
            else Result.failure(Exception("Key test failed: HTTP ${conn.responseCode}. Check key in AI Studio."))
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    private fun parseText(raw: String): String {
        return try {
            val root = JSONObject(raw)
            val candidates = root.getJSONArray("candidates")
            if (candidates.length() == 0) return ""
            val content = candidates.getJSONObject(0).getJSONObject("content")
            val parts = content.getJSONArray("parts")
            val sb = StringBuilder()
            for (i in 0 until parts.length()) {
                val p = parts.getJSONObject(i)
                if (p.has("text")) sb.append(p.getString("text"))
            }
            sb.toString()
        } catch (e: Exception) {
            ""
        }
    }

    private fun parseError(raw: String?): String {
        if (raw.isNullOrBlank()) return "Unknown error"
        return try {
            val e = JSONObject(raw).optJSONObject("error")
            e?.optString("message") ?: raw.take(300)
        } catch (ex: Exception) {
            raw.take(300)
        }
    }
}
