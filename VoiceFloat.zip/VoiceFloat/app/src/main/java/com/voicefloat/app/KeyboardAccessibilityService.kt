package com.voicefloat.app

import android.accessibilityservice.AccessibilityService
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.PixelFormat
import android.os.Handler
import android.os.Looper
import android.os.Vibrator
import android.view.Gravity
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityWindowInfo
import android.widget.ImageButton
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

/**
 * FAST KEYBOARD DETECTION - design for <1s, typically 50-150ms:
 *
 * 1. notificationTimeout = 0 in XML -> system delivers events immediately, no batching.
 * 2. Overlay view is PRE-INFLATED once in onServiceConnected(). Showing = just
 *    WindowManager.addView(), hiding = removeView(). No inflate / findViewById / disk / network
 *    in the detection path.
 * 3. onAccessibilityEvent does almost nothing: it only posts a 30ms coalescing runnable.
 *    The runnable calls getWindows() and checks for TYPE_INPUT_METHOD visible.
 *    Bursts of window events collapse into one check.
 * 4. No polling, no UsageStats, no loops, no Handler.postDelayed > 30ms.
 *
 * Privacy: This service NEVER reads text, passwords, or keystrokes.
 * It only asks: "is there a window of type INPUT_METHOD that is visible?"
 * rootInActiveWindow is used ONLY to know if WE are the foreground app
 * (so we hide the button in our own settings screen).
 *
 * Realme / realme UI 4.0 note: On some realme builds getWindows() can be
 * empty for a frame. Fallback: if a focused node was editable within the
 * last 800ms, treat that as keyboard-about-to-open and show the button.
 * This fallback never reads the node's text.
 */
class KeyboardAccessibilityService : AccessibilityService() {

    private var windowManager: WindowManager? = null
    private var overlayView: View? = null
    private var overlayParams: WindowManager.LayoutParams? = null
    private var isOverlayAdded = false
    private var isKeyboardVisible = false

    private var currentState = VoiceDictationService.STATE_IDLE
    private var lastEditableFocusTime = 0L

    private val mainHandler = Handler(Looper.getMainLooper())
    private val checkRunnable = Runnable { checkKeyboardNow() }

    private lateinit var micButton: ImageButton
    private lateinit var pauseButton: ImageButton
    private lateinit var stopButton: ImageButton
    private lateinit var deleteButton: ImageButton
    private lateinit var statusText: TextView
    private lateinit var recordingControls: LinearLayout
    private lateinit var resultCard: LinearLayout
    private lateinit var resultText: TextView
    private lateinit var copyAgainButton: TextView
    private lateinit var deleteResultButton: TextView

    private val serviceReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            when (intent?.action) {
                VoiceDictationService.BROADCAST_STATE -> {
                    val s = intent.getStringExtra(VoiceDictationService.EXTRA_STATE) ?: return
                    updateState(s)
                }
                VoiceDictationService.BROADCAST_RESULT -> {
                    val text = intent.getStringExtra(VoiceDictationService.EXTRA_TEXT) ?: return
                    showResult(text)
                }
                VoiceDictationService.BROADCAST_ERROR -> {
                    val err = intent.getStringExtra(VoiceDictationService.EXTRA_ERROR) ?: "Error"
                    statusText.text = err
                    Toast.makeText(this@KeyboardAccessibilityService, err, Toast.LENGTH_LONG).show()
                    updateState(VoiceDictationService.STATE_IDLE)
                }
            }
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        initOverlay()
        val filter = IntentFilter().apply {
            addAction(VoiceDictationService.BROADCAST_STATE)
            addAction(VoiceDictationService.BROADCAST_RESULT)
            addAction(VoiceDictationService.BROADCAST_ERROR)
        }
        registerReceiver(serviceReceiver, filter, RECEIVER_NOT_EXPORTED)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return
        when (event.eventType) {
            AccessibilityEvent.TYPE_WINDOWS_CHANGED,
            AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED,
            AccessibilityEvent.TYPE_VIEW_FOCUSED,
            AccessibilityEvent.TYPE_VIEW_CLICKED -> {
                // Fallback signal: editable focus usually means keyboard is about to open.
                // We only store timestamp, never read text.
                try {
                    if (event.eventType == AccessibilityEvent.TYPE_VIEW_FOCUSED) {
                        val src = event.source
                        if (src != null && src.isEditable) {
                            lastEditableFocusTime = System.currentTimeMillis()
                            src.recycle()
                        }
                    }
                } catch (_: Exception) {}
                // Coalesce bursts: 30ms is enough to collapse IME show/hide bursts,
                // short enough to stay well under 1s.
                mainHandler.removeCallbacks(checkRunnable)
                mainHandler.postDelayed(checkRunnable, 30)
            }
        }
    }

    override fun onInterrupt() {}

    override fun onDestroy() {
        try { unregisterReceiver(serviceReceiver) } catch (_: Exception) {}
        hideOverlay()
        super.onDestroy()
    }

    // ---------- Detection ----------

    private fun checkKeyboardNow() {
        var imeVisible = false
        try {
            val wins = windows
            for (w in wins) {
                if (w.type == AccessibilityWindowInfo.TYPE_INPUT_METHOD && w.isVisible) {
                    imeVisible = true
                    break
                }
            }
        } catch (_: Exception) { }

        // Realme fallback: editable focus in last 800ms
        if (!imeVisible) {
            val sinceFocus = System.currentTimeMillis() - lastEditableFocusTime
            if (sinceFocus in 0..800) imeVisible = true
        }

        // Hide in our own app settings to avoid covering the API key field.
        // Exception: if user is testing in our own test field, still show - handled by
        // MainActivity sending a broadcast? Simple rule: hide only if top package is ours
        // AND keyboard is visible but we are in MainActivity. We detect via root package.
        var inOwnApp = false
        try {
            val root = rootInActiveWindow
            if (root != null) {
                inOwnApp = root.packageName?.toString() == packageName
                root.recycle()
            }
        } catch (_: Exception) {}

        val shouldShow = imeVisible && !inOwnApp
        if (shouldShow != isKeyboardVisible) {
            isKeyboardVisible = shouldShow
            if (shouldShow) showOverlay() else hideOverlay()
        }
    }

    // ---------- Overlay ----------

    private fun initOverlay() {
        try {
            windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
            val inflater = LayoutInflater.from(this)
            val view = inflater.inflate(R.layout.overlay_floating, null)
            overlayView = view

            micButton = view.findViewById(R.id.micButton)
            pauseButton = view.findViewById(R.id.pauseButton)
            stopButton = view.findViewById(R.id.stopButton)
            deleteButton = view.findViewById(R.id.deleteButton)
            statusText = view.findViewById(R.id.statusText)
            recordingControls = view.findViewById(R.id.recordingControls)
            resultCard = view.findViewById(R.id.resultCard)
            resultText = view.findViewById(R.id.resultText)
            copyAgainButton = view.findViewById(R.id.copyAgainButton)
            deleteResultButton = view.findViewById(R.id.deleteResultButton)

            overlayParams = WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT
            ).apply {
                gravity = Gravity.BOTTOM or Gravity.END
                x = 28
                y = 340 // above keyboard, tuned for realme 9i 6.6" screen
            }

            micButton.setOnClickListener { onMicClicked() }
            pauseButton.setOnClickListener { onPauseClicked() }
            stopButton.setOnClickListener { onMicClicked() } // stop = same as mic toggle
            deleteButton.setOnClickListener { onDeleteClicked() }
            copyAgainButton.setOnClickListener {
                val text = resultText.text.toString()
                if (text.isNotBlank()) {
                    val cm = getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
                    cm.setPrimaryClip(android.content.ClipData.newPlainText("VoiceFloat", text))
                    Toast.makeText(this, "Copied again", Toast.LENGTH_SHORT).show()
                }
            }
            deleteResultButton.setOnClickListener { onDeleteClicked() }

            // Drag to move: touch on mic area drags whole overlay.
            var lastX = 0f
            var lastY = 0f
            var isDragging = false
            micButton.setOnTouchListener { _, ev ->
                when (ev.action) {
                    MotionEvent.ACTION_DOWN -> {
                        lastX = ev.rawX; lastY = ev.rawY; isDragging = false; false
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = ev.rawX - lastX
                        val dy = ev.rawY - lastY
                        if (Math.abs(dx) > 8 || Math.abs(dy) > 8) isDragging = true
                        if (isDragging) {
                            overlayParams?.let { p ->
                                // Gravity is BOTTOM|END, so moving finger up/right needs inverted math
                                p.x = (p.x - dx).toInt()
                                p.y = (p.y - dy).toInt()
                                if (isOverlayAdded) {
                                    try { windowManager?.updateViewLayout(overlayView, p) } catch (_: Exception) {}
                                }
                            }
                            lastX = ev.rawX; lastY = ev.rawY
                        }
                        isDragging
                    }
                    MotionEvent.ACTION_UP -> {
                        val wasDragging = isDragging
                        isDragging = false
                        wasDragging // if dragging, consume so click does not fire
                    }
                    else -> false
                }
            }
        } catch (e: Exception) {
            // Overlay permission not yet granted - MainActivity will prompt.
        }
    }

    private fun showOverlay() {
        if (overlayView == null || isOverlayAdded) return
        try {
            windowManager?.addView(overlayView, overlayParams)
            isOverlayAdded = true
        } catch (_: Exception) { }
    }

    private fun hideOverlay() {
        if (!isOverlayAdded) return
        try {
            windowManager?.removeView(overlayView)
        } catch (_: Exception) {}
        isOverlayAdded = false
    }

    // ---------- Recording controls ----------

    private fun onMicClicked() {
        vibrate()
        when (currentState) {
            VoiceDictationService.STATE_IDLE,
            VoiceDictationService.STATE_DONE,
            VoiceDictationService.STATE_DELETED -> {
                resultCard.visibility = View.GONE
                startService(Intent(this, VoiceDictationService::class.java).apply {
                    action = VoiceDictationService.ACTION_START
                })
                updateState(VoiceDictationService.STATE_RECORDING)
            }
            VoiceDictationService.STATE_RECORDING,
            VoiceDictationService.STATE_PAUSED -> {
                startService(Intent(this, VoiceDictationService::class.java).apply {
                    action = VoiceDictationService.ACTION_STOP
                })
                updateState(VoiceDictationService.STATE_PROCESSING)
            }
            VoiceDictationService.STATE_PROCESSING -> {
                Toast.makeText(this, "Transcribing, please wait...", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun onPauseClicked() {
        if (currentState == VoiceDictationService.STATE_RECORDING) {
            startService(Intent(this, VoiceDictationService::class.java).apply {
                action = VoiceDictationService.ACTION_PAUSE
            })
        } else if (currentState == VoiceDictationService.STATE_PAUSED) {
            startService(Intent(this, VoiceDictationService::class.java).apply {
                action = VoiceDictationService.ACTION_RESUME
            })
        }
    }

    private fun onDeleteClicked() {
        // Delete last recording: discard current OR delete last transcribed result.
        if (currentState == VoiceDictationService.STATE_RECORDING ||
            currentState == VoiceDictationService.STATE_PAUSED) {
            startService(Intent(this, VoiceDictationService::class.java).apply {
                action = VoiceDictationService.ACTION_CANCEL
            })
            Toast.makeText(this, "Recording discarded - tap mic to restart", Toast.LENGTH_SHORT).show()
        } else {
            startService(Intent(this, VoiceDictationService::class.java).apply {
                action = VoiceDictationService.ACTION_DELETE_LAST
            })
            resultCard.visibility = View.GONE
        }
        updateState(VoiceDictationService.STATE_IDLE)
    }

    private fun updateState(state: String) {
        currentState = state
        when (state) {
            VoiceDictationService.STATE_IDLE -> {
                statusText.text = "Tap to dictate"
                recordingControls.visibility = View.GONE
                micButton.setImageResource(android.R.drawable.ic_btn_speak_now)
                micButton.alpha = 1f
            }
            VoiceDictationService.STATE_RECORDING -> {
                statusText.text = "Recording... tap to stop"
                recordingControls.visibility = View.VISIBLE
                pauseButton.setImageResource(android.R.drawable.ic_media_pause)
                micButton.setImageResource(android.R.drawable.ic_media_pause)
            }
            VoiceDictationService.STATE_PAUSED -> {
                statusText.text = "Paused - tap Resume"
                recordingControls.visibility = View.VISIBLE
                pauseButton.setImageResource(android.R.drawable.ic_media_play)
            }
            VoiceDictationService.STATE_PROCESSING -> {
                statusText.text = "Transcribing..."
                recordingControls.visibility = View.GONE
                micButton.setImageResource(android.R.drawable.ic_popup_sync)
            }
            VoiceDictationService.STATE_DONE -> {
                statusText.text = "Copied to clipboard"
                recordingControls.visibility = View.GONE
                micButton.setImageResource(android.R.drawable.ic_btn_speak_now)
            }
            VoiceDictationService.STATE_DELETED -> {
                statusText.text = "Deleted - tap to dictate"
                recordingControls.visibility = View.GONE
                resultCard.visibility = View.GONE
                micButton.setImageResource(android.R.drawable.ic_btn_speak_now)
            }
        }
    }

    private fun showResult(text: String) {
        resultText.text = text
        resultCard.visibility = View.VISIBLE
        updateState(VoiceDictationService.STATE_DONE)
        // Auto-hide result card after 12s, but keep mic button.
        mainHandler.postDelayed({
            if (currentState == VoiceDictationService.STATE_DONE) resultCard.visibility = View.GONE
        }, 12_000)
    }

    private fun vibrate() {
        try {
            val v = getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
            v.vibrate(30)
        } catch (_: Exception) {}
    }
}
