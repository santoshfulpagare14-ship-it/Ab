package com.voicefloat.app

import android.Manifest
import android.accessibilityservice.AccessibilityServiceInfo
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.view.accessibility.AccessibilityManager
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

/**
 * Setup screen: explains EVERY permission in plain language, lets user
 * enter Gemini API key, and shows live status for each permission.
 *
 * Why each permission:
 * - Display over other apps: to show floating mic button above keyboard in any app.
 * - Microphone: to record voice for dictation. Audio is sent only to Gemini, never stored except last cache file.
 * - Accessibility: ONLY to detect when keyboard opens (IME window visible). Does NOT read text/passwords/keystrokes.
 * - Notifications: to show ongoing recording notification (required for foreground service).
 * - Battery optimisation exemption: so realme UI does not kill recording when screen off.
 */
class MainActivity : AppCompatActivity() {

    private lateinit var secureStore: SecureKeyStore
    private lateinit var apiKeyInput: EditText
    private lateinit var statusText: TextView
    private lateinit var overlayStatus: TextView
    private lateinit var micStatus: TextView
    private lateinit var accessibilityStatus: TextView
    private lateinit var batteryStatus: TextView
    private lateinit var lastTextView: TextView
    private lateinit var testField: EditText

    private val scope = CoroutineScope(Dispatchers.Main)

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            when (intent?.action) {
                VoiceDictationService.BROADCAST_RESULT -> {
                    val t = intent.getStringExtra(VoiceDictationService.EXTRA_TEXT) ?: return
                    lastTextView.text = "Last: $t\n\nCopied to clipboard. Paste in any app (long-press > Paste)."
                    secureStore.saveLastTranscription(t)
                }
                VoiceDictationService.BROADCAST_ERROR -> {
                    val e = intent.getStringExtra(VoiceDictationService.EXTRA_ERROR) ?: "Error"
                    Toast.makeText(this@MainActivity, e, Toast.LENGTH_LONG).show()
                    statusText.text = e
                }
                VoiceDictationService.BROADCAST_STATE -> {
                    val s = intent.getStringExtra(VoiceDictationService.EXTRA_STATE) ?: return
                    if (s == VoiceDictationService.STATE_DELETED) {
                        lastTextView.text = "Last recording deleted."
                        secureStore.clearLastTranscription()
                    }
                }
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        secureStore = SecureKeyStore(this)

        apiKeyInput = findViewById(R.id.apiKeyInput)
        statusText = findViewById(R.id.statusText)
        overlayStatus = findViewById(R.id.overlayStatus)
        micStatus = findViewById(R.id.micStatus)
        accessibilityStatus = findViewById(R.id.accessibilityStatus)
        batteryStatus = findViewById(R.id.batteryStatus)
        lastTextView = findViewById(R.id.lastTextView)
        testField = findViewById(R.id.testField)

        apiKeyInput.setText(secureStore.getApiKey())

        findViewById<Button>(R.id.saveKeyButton).setOnClickListener { saveKey() }
        findViewById<Button>(R.id.testKeyButton).setOnClickListener { testKey() }
        findViewById<Button>(R.id.getKeyButton).setOnClickListener {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://aistudio.google.com/apikey")))
        }
        findViewById<Button>(R.id.overlayButton).setOnClickListener { openOverlaySettings() }
        findViewById<Button>(R.id.micButton).setOnClickListener { requestMic() }
        findViewById<Button>(R.id.accessibilityButton).setOnClickListener { openAccessibilitySettings() }
        findViewById<Button>(R.id.batteryButton).setOnClickListener { requestBatteryExemption() }
        findViewById<Button>(R.id.notificationButton).setOnClickListener { requestNotificationPermission() }
        findViewById<Button>(R.id.testKeyboardButton).setOnClickListener { showTestKeyboard() }
        findViewById<Button>(R.id.deleteLastButton).setOnClickListener { deleteLast() }
        findViewById<Button>(R.id.howItWorksButton).setOnClickListener {
            Toast.makeText(this, "1. Open any app  2. Tap text field  3. Keyboard opens  4. Mic button appears  5. Tap mic to dictate, tap again to copy", Toast.LENGTH_LONG).show()
        }

        val filter = IntentFilter().apply {
            addAction(VoiceDictationService.BROADCAST_RESULT)
            addAction(VoiceDictationService.BROADCAST_ERROR)
            addAction(VoiceDictationService.BROADCAST_STATE)
        }
        registerReceiver(receiver, filter, RECEIVER_NOT_EXPORTED)

        val last = secureStore.getLastTranscription()
        if (last.isNotBlank()) lastTextView.text = "Last: $last"
    }

    override fun onResume() {
        super.onResume()
        refreshStatuses()
    }

    override fun onDestroy() {
        try { unregisterReceiver(receiver) } catch (_: Exception) {}
        super.onDestroy()
    }

    private fun refreshStatuses() {
        overlayStatus.text = if (Settings.canDrawOverlays(this)) "✅ Granted" else "❌ Not granted - tap button below"
        micStatus.text = if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) "✅ Granted" else "❌ Not granted - tap button below"
        accessibilityStatus.text = if (isAccessibilityEnabled()) "✅ Enabled" else "❌ Not enabled - tap button below"
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        batteryStatus.text = if (pm.isIgnoringBatteryOptimizations(packageName)) "✅ Not optimised (good)" else "⚠️ Optimised - tap to exempt (realme may kill recording)"
    }

    private fun isAccessibilityEnabled(): Boolean {
        val am = getSystemService(Context.ACCESSIBILITY_SERVICE) as AccessibilityManager
        val enabled = am.getEnabledAccessibilityServiceList(AccessibilityServiceInfo.FEEDBACK_GENERIC)
        for (info in enabled) {
            if (info.resolveInfo.serviceInfo.packageName == packageName &&
                info.resolveInfo.serviceInfo.name.contains("KeyboardAccessibilityService")) return true
        }
        return false
    }

    private fun saveKey() {
        val key = apiKeyInput.text.toString().trim()
        if (key.length < 10) {
            Toast.makeText(this, "Paste a valid Gemini API key (starts with AIza...)", Toast.LENGTH_LONG).show()
            return
        }
        secureStore.saveApiKey(key)
        statusText.text = "API key saved securely."
        Toast.makeText(this, "API key saved", Toast.LENGTH_SHORT).show()
    }

    private fun testKey() {
        val key = apiKeyInput.text.toString().trim()
        if (key.isBlank()) {
            Toast.makeText(this, "Enter API key first", Toast.LENGTH_SHORT).show()
            return
        }
        statusText.text = "Testing key..."
        scope.launch {
            val r = GeminiTranscriber.testKey(key)
            if (r.isSuccess) {
                statusText.text = "✅ Key works! Save it, then try dictation."
                secureStore.saveApiKey(key)
            } else {
                statusText.text = "❌ ${r.exceptionOrNull()?.message}"
            }
        }
    }

    private fun openOverlaySettings() {
        try {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        } catch (e: Exception) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION))
        }
        Toast.makeText(this, "Find VoiceFloat > Allow display over other apps", Toast.LENGTH_LONG).show()
    }

    private fun requestMic() {
        ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), 101)
    }

    private fun openAccessibilitySettings() {
        startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        Toast.makeText(this, "Find VoiceFloat Keyboard Detector > Turn ON. It only detects keyboard opening.", Toast.LENGTH_LONG).show()
    }

    private fun requestBatteryExemption() {
        try {
            val intent = Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName"))
            startActivity(intent)
        } catch (e: Exception) {
            startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
        }
        Toast.makeText(this, "Allow VoiceFloat to run without battery restriction", Toast.LENGTH_LONG).show()
    }

    private fun requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 102)
        } else {
            Toast.makeText(this, "Notifications already allowed on this Android version", Toast.LENGTH_SHORT).show()
        }
    }

    private fun showTestKeyboard() {
        testField.requestFocus()
        val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        imm.showSoftInput(testField, InputMethodManager.SHOW_IMPLICIT)
        Toast.makeText(this, "Keyboard should open. Floating mic should appear (in other apps). In this app it is hidden so it does not cover settings - test in WhatsApp / Notes.", Toast.LENGTH_LONG).show()
    }

    private fun deleteLast() {
        startService(Intent(this, VoiceDictationService::class.java).apply {
            action = VoiceDictationService.ACTION_DELETE_LAST
        })
        lastTextView.text = "Last recording deleted."
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        refreshStatuses()
        if (requestCode == 101 && grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            Toast.makeText(this, "Mic granted", Toast.LENGTH_SHORT).show()
        }
    }
}
