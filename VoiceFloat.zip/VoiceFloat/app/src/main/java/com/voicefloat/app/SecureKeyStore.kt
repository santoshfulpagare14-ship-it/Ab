package com.voicefloat.app

import android.content.Context
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

/**
 * Secure storage for the Gemini API key.
 * Uses EncryptedSharedPreferences (AES256-GCM). Falls back to plain prefs
 * only if encrypted storage fails on a specific OEM ROM.
 */
class SecureKeyStore(context: Context) {

    private val appContext = context.applicationContext

    private val encryptedPrefs by lazy {
        try {
            val masterKey = MasterKey.Builder(appContext)
                .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
                .build()
            EncryptedSharedPreferences.create(
                appContext,
                "voicefloat_secure",
                masterKey,
                EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
                EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
            )
        } catch (e: Exception) {
            null
        }
    }

    private val fallbackPrefs by lazy {
        appContext.getSharedPreferences("voicefloat_fallback", Context.MODE_PRIVATE)
    }

    fun saveApiKey(key: String) {
        val trimmed = key.trim()
        encryptedPrefs?.edit()?.putString(KEY_API, trimmed)?.apply()
            ?: fallbackPrefs.edit().putString(KEY_API, trimmed).apply()
    }

    fun getApiKey(): String {
        return encryptedPrefs?.getString(KEY_API, "") ?: fallbackPrefs.getString(KEY_API, "") ?: ""
    }

    fun clearApiKey() {
        encryptedPrefs?.edit()?.remove(KEY_API)?.apply()
        fallbackPrefs.edit().remove(KEY_API).apply()
    }

    fun hasApiKey(): Boolean = getApiKey().isNotBlank()

    fun saveLastTranscription(text: String) {
        appContext.getSharedPreferences("voicefloat_history", Context.MODE_PRIVATE)
            .edit().putString(KEY_LAST, text).apply()
    }

    fun getLastTranscription(): String {
        return appContext.getSharedPreferences("voicefloat_history", Context.MODE_PRIVATE)
            .getString(KEY_LAST, "") ?: ""
    }

    fun clearLastTranscription() {
        appContext.getSharedPreferences("voicefloat_history", Context.MODE_PRIVATE)
            .edit().remove(KEY_LAST).apply()
    }

    companion object {
        private const val KEY_API = "gemini_api_key"
        private const val KEY_LAST = "last_transcription"
    }
}
