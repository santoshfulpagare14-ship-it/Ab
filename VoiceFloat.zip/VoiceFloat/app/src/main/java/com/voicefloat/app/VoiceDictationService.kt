package com.voicefloat.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.media.MediaRecorder
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import android.widget.Toast
import androidx.core.app.NotificationCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import java.io.File

/**
 * Foreground service that owns recording.
 * Keeps working when screen is off: foreground + partial wake lock.
 * AccessibilityService never does recording - it only shows/hides the button.
 * This service is started/stopped by the overlay button.
 */
class VoiceDictationService : Service() {

    companion object {
        const val ACTION_START = "com.voicefloat.app.START"
        const val ACTION_STOP = "com.voicefloat.app.STOP"
        const val ACTION_PAUSE = "com.voicefloat.app.PAUSE"
        const val ACTION_RESUME = "com.voicefloat.app.RESUME"
        const val ACTION_DELETE_LAST = "com.voicefloat.app.DELETE_LAST"
        const val ACTION_CANCEL = "com.voicefloat.app.CANCEL"

        const val BROADCAST_STATE = "com.voicefloat.app.STATE"
        const val BROADCAST_RESULT = "com.voicefloat.app.RESULT"
        const val BROADCAST_ERROR = "com.voicefloat.app.ERROR"
        const val EXTRA_STATE = "state"
        const val EXTRA_TEXT = "text"
        const val EXTRA_ERROR = "error"

        const val STATE_IDLE = "idle"
        const val STATE_RECORDING = "recording"
        const val STATE_PAUSED = "paused"
        const val STATE_PROCESSING = "processing"
        const val STATE_DONE = "done"
        const val STATE_DELETED = "deleted"

        private const val CHANNEL_ID = "voicefloat_recording"
        private const val NOTIF_ID = 1001
    }

    private var recorder: MediaRecorder? = null
    private var recordingFile: File? = null
    private var isRecording = false
    private var isPaused = false
    private var wakeLock: PowerManager.WakeLock? = null
    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())
    private lateinit var secureStore: SecureKeyStore

    override fun onCreate() {
        super.onCreate()
        secureStore = SecureKeyStore(this)
        createChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> startRecording()
            ACTION_STOP -> stopAndTranscribe()
            ACTION_PAUSE -> pauseRecording()
            ACTION_RESUME -> resumeRecording()
            ACTION_CANCEL -> cancelRecording()
            ACTION_DELETE_LAST -> deleteLast()
        }
        return START_NOT_STICKY
    }

    private fun startRecording() {
        if (isRecording) return
        try {
            val file = File(cacheDir, "voicefloat_last.m4a")
            if (file.exists()) file.delete()
            recordingFile = file

            val rec = if (Build.VERSION.SDK_INT >= 31) MediaRecorder(this) else MediaRecorder()
            rec.setAudioSource(MediaRecorder.AudioSource.MIC)
            rec.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            rec.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
            rec.setAudioEncodingBitRate(128_000)
            rec.setAudioSamplingRate(44_100)
            rec.setOutputFile(file.absolutePath)
            rec.prepare()
            rec.start()
            recorder = rec
            isRecording = true
            isPaused = false

            val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
            wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "VoiceFloat::Recording").apply {
                acquire(10 * 60 * 1000L)
            }
            startForeground(NOTIF_ID, buildNotification("Recording - tap floating button to stop"))
            broadcastState(STATE_RECORDING)
        } catch (e: Exception) {
            broadcastError("Mic failed: ${e.message}. Check mic permission and close other recorder apps.")
            stopSelf()
        }
    }

    private fun pauseRecording() {
        if (!isRecording || isPaused) return
        try {
            if (Build.VERSION.SDK_INT >= 24) recorder?.pause()
            isPaused = true
            startForeground(NOTIF_ID, buildNotification("Paused - tap Resume to continue"))
            broadcastState(STATE_PAUSED)
        } catch (e: Exception) {
            broadcastError("Pause not supported on this device: ${e.message}")
        }
    }

    private fun resumeRecording() {
        if (!isRecording || !isPaused) return
        try {
            if (Build.VERSION.SDK_INT >= 24) recorder?.resume()
            isPaused = false
            startForeground(NOTIF_ID, buildNotification("Recording - tap floating button to stop"))
            broadcastState(STATE_RECORDING)
        } catch (e: Exception) {
            broadcastError("Resume failed: ${e.message}")
        }
    }

    private fun cancelRecording() {
        // Discard current recording, do NOT transcribe, do NOT copy.
        try { recorder?.stop() } catch (_: Exception) {}
        try { recorder?.release() } catch (_: Exception) {}
        recorder = null
        isRecording = false
        isPaused = false
        recordingFile?.delete()
        recordingFile = null
        releaseWakeLock()
        stopForeground(STOP_FOREGROUND_REMOVE)
        broadcastState(STATE_DELETED)
        stopSelf()
    }

    private fun stopAndTranscribe() {
        if (!isRecording) return
        val file = recordingFile
        try { recorder?.stop() } catch (_: Exception) {}
        try { recorder?.release() } catch (_: Exception) {}
        recorder = null
        isRecording = false
        isPaused = false
        releaseWakeLock()
        broadcastState(STATE_PROCESSING)
        startForeground(NOTIF_ID, buildNotification("Transcribing with Gemini..."))

        if (file == null || !file.exists()) {
            broadcastError("No recording found.")
            stopSelf()
            return
        }
        val apiKey = secureStore.getApiKey()
        if (apiKey.isBlank()) {
            broadcastError("No Gemini API key. Open VoiceFloat > enter key from Google AI Studio, then try again. Recording saved in cache.")
            stopSelf()
            return
        }
        scope.launch {
            val result = GeminiTranscriber.transcribe(apiKey, file)
            result.onSuccess { text ->
                if (text == "[inaudible]") {
                    broadcastError("Could not hear clearly. Try again closer to mic.")
                } else {
                    copyToClipboard(text)
                    secureStore.saveLastTranscription(text)
                    sendBroadcast(Intent(BROADCAST_RESULT).apply { putExtra(EXTRA_TEXT, text) })
                    broadcastState(STATE_DONE)
                    Toast.makeText(this@VoiceDictationService, "Copied to clipboard", Toast.LENGTH_SHORT).show()
                }
            }.onFailure { e ->
                broadcastError(e.message ?: "Transcription failed")
            }
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
        }
    }

    private fun deleteLast() {
        // Delete last recording + last transcription. If clipboard still holds that text, clear it.
        try { recordingFile?.delete() } catch (_: Exception) {}
        val last = secureStore.getLastTranscription()
        secureStore.clearLastTranscription()
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        try {
            val clip = cm.primaryClip
            if (clip != null && clip.itemCount > 0 && clip.getItemAt(0).text?.toString() == last) {
                cm.setPrimaryClip(ClipData.newPlainText("", ""))
            }
        } catch (_: Exception) {}
        val f = File(cacheDir, "voicefloat_last.m4a")
        if (f.exists()) f.delete()
        sendBroadcast(Intent(BROADCAST_STATE).apply { putExtra(EXTRA_STATE, STATE_DELETED) })
        Toast.makeText(this, "Last recording deleted", Toast.LENGTH_SHORT).show()
    }

    private fun copyToClipboard(text: String) {
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("VoiceFloat dictation", text))
    }

    private fun broadcastState(state: String) {
        sendBroadcast(Intent(BROADCAST_STATE).apply { putExtra(EXTRA_STATE, state) })
    }

    private fun broadcastError(msg: String) {
        sendBroadcast(Intent(BROADCAST_ERROR).apply { putExtra(EXTRA_ERROR, msg) })
    }

    private fun releaseWakeLock() {
        try { if (wakeLock?.isHeld == true) wakeLock?.release() } catch (_: Exception) {}
        wakeLock = null
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val ch = NotificationChannel(CHANNEL_ID, "Voice Dictation", NotificationManager.IMPORTANCE_LOW)
            ch.description = "Shows while recording / transcribing"
            (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(ch)
        }
    }

    private fun buildNotification(text: String): Notification {
        val openIntent = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val stopIntent = PendingIntent.getService(
            this, 1, Intent(this, VoiceDictationService::class.java).apply { action = ACTION_STOP },
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("VoiceFloat")
            .setContentText(text)
            .setContentIntent(openIntent)
            .setOngoing(true)
            .addAction(android.R.drawable.ic_media_pause, "Stop", stopIntent)
            .build()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        try { recorder?.release() } catch (_: Exception) {}
        releaseWakeLock()
        scope.cancel()
        super.onDestroy()
    }
}
